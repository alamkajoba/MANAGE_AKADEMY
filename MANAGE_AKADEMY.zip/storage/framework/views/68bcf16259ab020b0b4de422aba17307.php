<div class="card shadow mb-4">
            <div class="justify-content-between card-header py-3 d-flex">
                <form method="GET"
                    class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
                    <div>
                        <h3>LISTE DES FRAIS</h3>
                    </div>
                </form>
                    <div class="col-auto">
                    </div>
                        <!-- confirm modal Modal-->
                        <div class="modal fade" id="confirmModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                            aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Confirmer la commande / Total:Fc</h5>
                                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">×</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <div>
                                            <form method="GET">
                                                <?php echo csrf_field(); ?>
                                                <input wire:model="customername" id="customername"  placeholder="Client name" class="form-control bg-light small" type="text">
                                                <input wire:model="table" id="table" placeholder="Table" class="form-control bg-light small" type="text">
                                            
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button wire:click="destroyCart()" class="btn btn-danger mx-auto" type="button" data-dismiss="modal">Annuler</button>
                                        <button wire:click="submitOrder()" class="btn btn-success mx-auto" type="submit">Valider</button>
                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>
            </div>

            
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100px" cellspacing="0">
                        
                        <div class="input-group col-lg-4 my-3">
                            <input 
                                wire:model.live.debounce.100ms="search" 
                                type="text" 
                                class="form-control bg-light small" 
                                placeholder="Taper un nom..."
                            />
                        </div>
                        
                            
                        <thead>
                        <tr>
                            <th>Nom</th>
                            <th>Description</th>
                            <th>Montant</th>
                           
                            <th colspan="3">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $fees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($fes->name); ?></td>
                                <td><?php echo e($fes->description); ?></td>
                                <td><?php echo e($fes->amount); ?></td>
                                <td><button class="btn btn-info">Détail</button></td>
                                <td><a href="<?php echo e(route('fees.update',$fes->id)); ?>" class="btn btn-success">Modifier</a></td>
                                <td><button wire:click="deletefees(<?php echo e($fes->id); ?>)"  wire:confirm="voulez-vous vraiment supprimé?" class="btn btn-danger">Supprimer</button></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </tbody>
                    </table>

                </div>  
                
                    <div class="mt-4">
                        
                    </div>
            </div>  
        </div>  <?php /**PATH C:\Users\MAITRE\Desktop\MANAGE_AKADEMY\MANAGE_AKADEMY\resources\views/livewire/module/fees/fees-index.blade.php ENDPATH**/ ?>