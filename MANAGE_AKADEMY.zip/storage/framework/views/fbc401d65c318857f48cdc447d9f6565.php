<div class="card shadow mb-4">
        <div class="justify-content-between card-header py-3 d-flex">
                <div>
                    <h3>FILTRE DE RECOUVREMENT</h3>
                </div> 
                <div>
                    <button style="background-color: rgb(7, 7, 99)" class="btn text-white fa fa-print">Imprimer</button>
                </div>
        </div>
        
        <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100px" cellspacing="0">
                
                <div class="input-group col-lg-4 my-3">
                    <input 
                        wire:model.live.debounce.100ms="search" 
                        type="text" 
                        class="form-control bg-light small" 
                        placeholder="Taper un nom..."
                    />
                </div>
                
                    
                <thead>
                    <tr><td colspan="4">Liste des etudiants en ordre avec .............</td></tr>
                    <tr style="background-color: rgb(7, 7, 99)" class="text-white">
                        <th>Nom</th>
                        <th>Postnom</th>
                        <th>Prénom</th>
                        <th>Matricule</th>
                    </tr>
                </thead>
                <tbody>
                    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $recovery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recoveries): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($recoveries->id); ?></td>
                            <td><?php echo e($recoveries->enrollment_id); ?></td>
                            <td><?php echo e($recoveries->fees_id); ?></td>
                            <td>HUYHGIUOUB</td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="px-6 py-2.5 text-danger whitespace-nowrap text">
                                Oups! Aucun Produit trouvé.
                            </td>
                        </tr>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </tbody>
            </table>

        </div>  
        
            <div class="mt-4">
                
            </div>
    </div>  
</div> <?php /**PATH C:\Users\MAITRE\Desktop\MANAGE_AKADEMY\MANAGE_AKADEMY\resources\views/livewire/module/recovery/recovery-create.blade.php ENDPATH**/ ?>