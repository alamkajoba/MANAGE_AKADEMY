            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Manage Akademy 2025</span>
                    </div>
                </div>
            </footer><?php /**PATH C:\Users\MAITRE\Desktop\MANAGE_AKADEMY\MANAGE_AKADEMY\resources\views/partials/partialsadmin/footer.blade.php ENDPATH**/ ?>