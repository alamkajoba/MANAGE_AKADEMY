<div class="card shadow mb-4">
        <div class="justify-content-between card-header py-3 d-flex">
                <div>
                    <h3>AJOUTER UN FRAIS</h3>
                </div> 
                <div>
                    <a href="#" style="background-color: rgb(7, 7, 99)" class="btn text-white">Liste la liste</a>
                </div>
        </div>
        
        <div class="justify-content-between card-header">
            <form wire:submit="save">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6">
                            <label for="">Nom du frais</label>
                            <input 
                                class="form-control"
                                type="text"
                                placeholder=""
                                wire:model="name"
                            >
                            <div><!--[if BLOCK]><![endif]--><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>

                            <label for="">Description</label>
                            <input 
                                class="form-control"
                                type="text"
                                placeholder=""
                                wire:model="description"
                            >
                            <div><!--[if BLOCK]><![endif]--><?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>

                            <label for="">Montant</label>
                            <input 
                                class="form-control"
                                type="text"
                                placeholder=""
                                wire:model="amount"
                            >
                            <div><!--[if BLOCK]><![endif]--><?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>
                    </div>
                    <div>
                        <button style="background-color: rgb(7, 7, 99)" class="btn text-white py-2 my-3">
                            Valider
                        </button>
                    </div>
                </div>
            </form>
            <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
        <div><?php echo e(session('message')); ?></div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>  
</div> 
<?php /**PATH C:\Users\MAITRE\Desktop\MANAGE_AKADEMY\MANAGE_AKADEMY\resources\views/livewire/module/fees/fees-create.blade.php ENDPATH**/ ?>