<div class="card shadow mb-4">
        <div class="justify-content-between card-header py-3 d-flex">
                <div>
                    <h3 class="m-0 font-weight-bold text-primary">RE-INSCRIPTION</h3>
                </div> 
                <div>
                    
                    <a href="<?php echo e(route('registration.index')); ?>" style="background-color: rgb(7, 7, 99)" class="btn text-white">
                        Voir la liste
                    </a>
                </div>
        </div>
        
        <div class="justify-content-between card-header">
            <form>
                <div class="container">
                    <div class="row">
                        <div class="col-md-6">
                            <label for="">Selectionner le nom de l'élève</label>
                            <input 
                                class="form-control"
                                type="text"
                                placeholder=""
                                wire:model="search"
                                wire:keyup="searchStundent"
                            >
                            <!--[if BLOCK]><![endif]--><?php if(!empty($items_student)): ?>
                                <ul class="list-group mt-2">
                                    <h5>Resultat de la recherche :</h5>
                                    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $items_student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items_students): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <a href="" class="list-group-item mb-2 flex bg-primary-200 hover:bg-primary-500"
                                            wire:click.prevent="selectStudent(<?php echo e($items_students['id']); ?>)">
                                            <?php echo e($items_students['first_name'].' '. $items_students['last_name'].' '.$items_students['code']); ?>

                                        </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <div class="list-group-item mb-2 flex bg-danger-200">
                                            Aucun(e) Etudiant(e)
                                        </div>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </ul>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                            <label for="">Classe</label>
                            <input 
                                class="form-control"
                                type="text"
                                placeholder=""
                                wire:model=""
                            >

                            <label for="">Option</label>
                            <input 
                                class="form-control"
                                type="text"
                                placeholder=""
                                wire:model=""
                            >
                        </div>
                    </div>
                    <div>
                        <button style="background-color: rgb(7, 7, 99)" class="btn text-white py-2 my-3">
                            Valider
                        </button>
                    </div>
                </div>
            </form>
        </div>  
</div> 
<?php /**PATH C:\Users\MAITRE\Desktop\MANAGE_AKADEMY\MANAGE_AKADEMY\resources\views/livewire/module/re-registration/re-registration-create.blade.php ENDPATH**/ ?>