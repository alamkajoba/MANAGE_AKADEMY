<!DOCTYPE html>
<html lang="en">

    <?php echo $__env->make('partials.partialsadmin.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">
        
        <?php echo $__env->make('partials.partialsadmin.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">
            
            <?php echo $__env->make('partials.partialsadmin.topbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <main>
                       <?php echo e($slot ?? ''); ?>

                    </main>

                </div>
            </div>
            
            <?php echo $__env->make('partials.partialsadmin.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        </div>
        <!-- End of Content Wrapper -->
    </div>
    
    <?php echo $__env->make('partials.partialsadmin.scriptfooter', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html><?php /**PATH C:\Users\MAITRE\Desktop\MANAGE_AKADEMY\MANAGE_AKADEMY\resources\views/layouts/topadmin.blade.php ENDPATH**/ ?>