<div class="card shadow mb-4">

    <!-- Header -->
    <div class="card-header py-3 d-flex justify-content-between align-items-center">
        <h3 >LISTE DES ELEVES</h3>
        <!-- Barre de recherche -->
        <div class="col-lg-4">
            <input 
                wire:model.live="search" 
                type="text" 
                class="form-control bg-light small"
                placeholder="Taper un nom..."
                aria-label="Recherche élève"
            />
        </div>
    </div>

    <!-- Table -->
    <div class="card-body">
        <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
            <div class="alert alert-success"><?php echo e(session('message')); ?></div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%">
                <thead style="background-color: rgb(7, 7, 99)" class="text-white">
                    <tr>
                        <th>Nom</th>
                        <th>Postnom</th>
                        <th>Prénom</th>
                        <th>Matricule</th>
                        <th>Classe</th>
                        <th>Option</th>
                        <th colspan="2">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $students): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($students->first_name); ?></td>
                            <td><?php echo e($students->middle_name); ?></td>
                            <td><?php echo e($students->last_name); ?></td>
                            <td><?php echo e($students->code); ?></td>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $students->enrollments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enrollment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td>
                                    <?php echo e($enrollment->level->class_name); ?> ème
                                </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $students->enrollments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enrollment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td>
                                    <?php echo e($enrollment->option->faculty_name); ?> 
                                </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            <td>
                                <a href="<?php echo e(route('registration.update', $students->id)); ?>" class="btn btn-warning btn-sm" title="Modifier l'étudiant">Modifier</a>
                            </td>
                            <td>
                                <button class="btn btn-danger btn-sm"
                                        wire:click="deleteStudent(<?php echo e($students->id); ?>)">
                                        Supprimer
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="9" class="text-center text-danger">Oups! Aucun étudiant trouvé.</td>
                        </tr>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <div class="mt-4">
            <?php echo e($student->links()); ?>

        </div>
    </div>

</div>
 <?php /**PATH C:\Users\MAITRE\Desktop\MANAGE_AKADEMY\MANAGE_AKADEMY\resources\views/livewire/module/registration/registration-index.blade.php ENDPATH**/ ?>