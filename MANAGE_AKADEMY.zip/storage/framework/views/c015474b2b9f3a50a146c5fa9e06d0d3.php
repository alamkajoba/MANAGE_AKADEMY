<div class="card shadow mb-4">
        <div class="justify-content-between card-header py-3 d-flex">
                <div>
                    <h3 class="m-0 font-weight-bold text-primary">MODIFICATION DES IDENTITES DE : <?php echo e($first_name); ?> <?php echo e($middle_name); ?> <?php echo e($last_name); ?></h3>
                </div> 
                <div>
                    <a href="<?php echo e(route('registration.index')); ?>" style="background-color: rgb(7, 7, 99)" class="btn text-white">Voir la liste</a>
                </div>
        </div>
        
        <div class="justify-content-between card-header">
            <form wire:submit="updateStudent(<?php echo e($stud); ?>)">
                <?php echo csrf_field(); ?>
                <div class="container">
                    <div class="row">
                        <div class="col-md-6">
                            <label for="middlename">Nom</label>
                            <input 
                                required
                                class="form-control"
                                type="text"
                                placeholder=""
                                wire:model="middle_name"
                            >
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                            <label for="lastname">Postnom</label>
                            <input 
                                required
                                class="form-control"
                                type="text"
                                placeholder=""
                                wire:model="last_name"
                            >
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['middle_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                            <label for="">Prénom</label>
                            <input 
                                required
                                class="form-control"
                                type="text"
                                placeholder=""
                                wire:model="first_name"
                            >
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                            <label for="">Genre</label>
                            <select wire:model="gender" class="form-control">
                                <option>Selectionner...</option>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->genders(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($gender); ?>"><?php echo e($gender); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </select>

                            <label for="">Date de naissance</label>
                            <input 
                                required
                                class="form-control"
                                type="date"
                                placeholder=""
                                wire:model="birth_date"
                            >

                            <label for="">Lieu de naissance</label>
                            <input 
                                required
                                class="form-control"
                                type="text"
                                placeholder=""
                                wire:model="birth_town"
                            >
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['birth_town'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <div class="col-md-6">

                            <label for="">Adresse</label>
                            <input 
                                required
                                class="form-control"
                                type="text"
                                placeholder=""
                                wire:model="address"
                            >
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                            <label for="">Nom Tuteur</label>
                            <input 
                                required
                                class="form-control"
                                type="text"
                                placeholder=""
                                wire:model="tutor_name"
                            >
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['tutor_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                            <label for="">Numéro Tuteur</label>
                            <input 
                                required
                                class="form-control"
                                type="text"
                                placeholder=""
                                wire:model="phone1"
                            >
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['phone1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                            <label for="">Numéro Tuteur 2</label>
                            <input 
                                class="form-control"
                                type="text"
                                placeholder=""
                                wire:model="phone2"
                            >
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['phone2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                    <div>
                        <button type="submit" style="background-color: rgb(7, 7, 99)" class="btn text-white py-2 my-3">
                            Valider
                        </button>
                    </div>
                </div>
            </form>
        </div>  
</div> 

<?php /**PATH C:\Users\MAITRE\Desktop\MANAGE_AKADEMY\MANAGE_AKADEMY\resources\views/livewire/module/registration/registration-update.blade.php ENDPATH**/ ?>