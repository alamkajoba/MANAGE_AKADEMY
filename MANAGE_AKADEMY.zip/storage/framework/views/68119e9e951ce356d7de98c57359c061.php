<div>
    <div class="alert alert-success">
        <h1 class="text-center">
            Bienvenu sur Manage Akademy 2025 <?php echo e(auth()->user()->name); ?>

        </h1>
    </div>
</div>
<?php /**PATH C:\Users\MAITRE\Desktop\MANAGE_AKADEMY\MANAGE_AKADEMY\resources\views/livewire/module/dashboard/dashboard.blade.php ENDPATH**/ ?>