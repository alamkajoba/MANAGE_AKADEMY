<div>
    <div class="row">
        <div class="col-lg-6 card mb-3 py-3">
            <div class="card-header py-3 d-flex justify-content-between align-items-center">
                <h3 >AJOUTER UNE OPTION</h3>
                <!-- Barre de recherche -->
            </div>
            <form wire:submit="submitOption()">
                <?php echo csrf_field(); ?>
                    <label for="middlename">Classe</label>
                    <input 
                        required
                        class="form-control"
                        type="text"
                        placeholder=""
                        wire:model="option_name"
                    >
                    <button type="submit" style="background-color: rgb(7, 7, 99)" class="btn text-white py-2 my-3">
                        Valider
                    </button>
            </form>
        </div>

        <div class="col-lg-6 card mb-3 py-3">
            <div class="card-header py-3 d-flex justify-content-between align-items-center">
                <h3 >LISTE DES OPTIONS</h3>
                <!-- Barre de recherche -->
            </div>
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%">
                    <thead style="background-color: rgb(7, 7, 99)" class="text-white">
                        <tr>
                            <th>Nom</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $faculty; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faculties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($faculties->faculty_name); ?></td>
                                <td>
                                    <button class="btn btn-danger btn-sm"
                                            wire:click="destroyOption(<?php echo e($faculties->id); ?>)"
                                            title="Supprimer l'étudiant">
                                            Supprimer
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="9" class="text-center text-danger">Oups! Aucun étudiant trouvé.</td>
                            </tr>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php /**PATH C:\Users\MAITRE\Desktop\MANAGE_AKADEMY\MANAGE_AKADEMY\resources\views/livewire/module/faculty/faculty.blade.php ENDPATH**/ ?>