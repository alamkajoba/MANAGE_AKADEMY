


<?php /**PATH C:\Users\MAITRE\Desktop\MANAGE_AKADEMY\MANAGE_AKADEMY\resources\views/components/application-logo.blade.php ENDPATH**/ ?>