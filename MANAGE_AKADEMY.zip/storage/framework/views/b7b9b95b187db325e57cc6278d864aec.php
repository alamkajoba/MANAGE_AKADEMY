<div class="card shadow mb-4">
        <div class="justify-content-between card-header py-3 d-flex">
                <div>
                    <h3>PAIEMENT</h3>
                </div> 
                <div>
                    
                    <button style="background-color: rgb(7, 7, 99)" class="btn text-white">
                        Voir la liste
                    </button>
                </div>
        </div>
        
        <div class="justify-content-between card-header">
            <form wire:submit="SavePayment">
                <?php echo csrf_field(); ?>
                <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
                    <div class="alert alert-info">
                        <?php echo e(session('message')); ?>

                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <div class="container">
                    <div class="row">
                        <div class="col-md-6">
                            <label for="">Selectionner le nom de l'élève</label>
                            <input 
                                class="form-control"
                                type="text"
                                placeholder=""
                                wire:model="search"
                                wire:keyup="searchStundent"
                            >

                            <!--[if BLOCK]><![endif]--><?php if(!empty($items_student)): ?>
                                <ul class="list-group mt-2">
                                    <h5>Resultat de la recherche :</h5>
                                    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $items_student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items_students): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <a href="" class="list-group-item mb-2 flex bg-primary-200 hover:bg-primary-500"
                                            wire:click.prevent="selectStudent(<?php echo e($items_students['id']); ?>)">
                                            <?php echo e($items_students['first_name'].' '. $items_students['middle_name'].' '. $items_students['last_name'].' '.$items_students['code']); ?>

                                        </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <div class="list-group-item mb-2 flex bg-danger-200">
                                            Aucun(e) Etudiant(e)
                                        </div>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </ul>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                            <label for="">Motif de paiement</label>
                            <input 
                                class="form-control"
                                type="text"
                                placeholder=""
                                wire:model="fees"
                                wire:keyup="searchFees"
                            >

                            <!--[if BLOCK]><![endif]--><?php if(!empty($items_fees)): ?>
                                <ul class="list-group mt-2">
                                    <h5>Resultat de la recherche :</h5>
                                    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $items_fees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items_feess): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <a href="" class="list-group-item mb-2 flex bg-primary-200 hover:bg-primary-500"
                                            wire:click.prevent="selectFees(<?php echo e($items_feess['id']); ?>)">
                                            <?php echo e($items_feess['name'].' '. $items_feess['description'].' '.$items_feess['amount'].' Fc'); ?>

                                        </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <div class="list-group-item mb-2 flex bg-danger-200">
                                            Aucun(e) Etudiant(e)
                                        </div>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </ul>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                    <div>
                        <button style="background-color: rgb(7, 7, 99)" class="btn text-white py-2 my-3">
                            Valider
                        </button>
                    </div>
                </div>
            </form>
        </div>  
</div> 

<?php /**PATH C:\Users\MAITRE\Desktop\MANAGE_AKADEMY\MANAGE_AKADEMY\resources\views/livewire/module/payment/payment-create.blade.php ENDPATH**/ ?>