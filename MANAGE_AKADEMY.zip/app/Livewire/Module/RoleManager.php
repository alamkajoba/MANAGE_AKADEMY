<?php

namespace App\Livewire\Module;

use Livewire\Component;

class RoleManager extends Component
{
    public function render()
    {
        return view('livewire.module.role-manager');
    }
}
